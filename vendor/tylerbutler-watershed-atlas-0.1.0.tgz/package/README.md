# @tylerbutler/watershed-atlas

Pure MV-register and observed-remove set operations for browsers and JavaScript
adapters. This package calls Watershed's existing kernels. It has no runtime npm
dependencies and exports no channels, transports, storage, timers, browser
objects, or Atlas trace types.

## Install

Version `0.1.0` is available as a reproducible release tarball. Build it with the
commands below, then copy the tarball to the consumer's dependency storage:

```sh
npm install ./vendor/tylerbutler-watershed-atlas-0.1.0.tgz
```

Import only `@tylerbutler/watershed-atlas`. Consumers need neither Gleam nor the
Watershed checkout. Do not import `build/`, generated modules, or sibling paths.
Registry publication is a separate release step; this task produces the tarball.

## API

Every function returns `{ ok: true, value }` or
`{ ok: false, error: { tag, message } }`. Inputs are validated at runtime, even
for JavaScript callers. States, deltas, visible values, and errors contain only
JSON data. Operations do not mutate their inputs.

```js
import {
  createMvRegister, write, merge, inspect, serialize, restore,
} from "@tylerbutler/watershed-atlas";

function unwrap(result) {
  if (!result.ok) throw new Error(`${result.error.tag}: ${result.error.message}`);
  return result.value;
}

const a = unwrap(write(unwrap(createMvRegister("a")), "raise crest"));
const b = unwrap(write(unwrap(createMvRegister("b")), "arm pump"));
const joined = unwrap(merge(a.state, b.operation));
unwrap(inspect(joined)).values; // ["arm pump", "raise crest"]
const resolved = unwrap(write(joined, "raise crest + arm pump"));
const snapshot = unwrap(serialize(resolved.state));
const continued = unwrap(restore(snapshot)); // continues replica "a"
```

| Export | Success value |
| --- | --- |
| `createMvRegister(replicaId)` | Empty `MvRegister` |
| `createOrSet(replicaId)` | Empty `OrSet` |
| `write(state, value)` | `{ state, operation }` for an MV-register |
| `add(state, value)` | `{ state, operation }` for an OR-set |
| `remove(state, value)` | `{ state, operation }` for an OR-set |
| `merge(state, remote)` | State after merging an explicit operation or state |
| `inspect(state)` | `{ values: string[], causal: State }` |
| `serialize(state)` | Canonical JSON string |
| `restore(json, replicaId?)` | Validated state; optional writer rebinding |

Replica IDs must be nonempty strings. Values are strings, including the empty
string. IDs must be unique across independent writers. Restore without a new ID
only when continuing the saved writer; do not fork a writer under the same ID
or resume an old snapshot after that writer has advanced elsewhere.

The register preserves concurrent writes, including two equal strings with
different tags. A write resolves only the writes it has observed. The OR-set
removes only observed additions, so a concurrent addition survives. Removing
an absent value is valid. Duplicate deltas have no further effect.

## Versioned state contract

All states have `version: 1`, `kind: "mv-register" | "or-set"`, and `replicaId`.
A tag is `{ replicaId: string, counter: number }`.

- MV-register: `entries: { tag, value }[]` and `clock: Tag[]`. Each clock
  replica appears once. A live tag matches its replica's current clock.
- OR-set: `counter`, `entries: { value, tags: Tag[] }[]`, and `tombstones: Tag[]`.
  The allocation counter covers every live and removed tag. Tombstones remain
  in snapshots to prevent stale additions from returning.

An operation is `{ version: 1, type: "operation", delta: State }`. Its delta
contains the metadata emitted by the kernel at authoring time. Deliver that
delta with `merge`; do not call `write`, `add`, or `remove` again to replay it.
MV-register deltas carry their observed clock; OR-set deltas are sparse.

`inspect().causal` is a copy of the full versioned state. No generated Gleam
types or lattice wire envelopes form part of this API. Unknown object fields
are discarded. Unsupported versions, malformed fields, duplicate tags,
contradictory metadata, mixed structure kinds, and known tag/value collisions
return tagged errors. Inputs must be ordinary data, not proxies or accessors.
This API validates structure and causality, not the identity of a remote writer.

Counters are nonnegative JavaScript safe integers; tags use positive counters.
`write` and `add` return `counter-exhausted` before an increment would lose
precision. There is no clock, random ID generation, or tombstone pruning.

States have fixed field order. Arrays sort by UTF-16 code-unit string order;
tags sort by replica ID, then counter. Visible values use that same string
order. There is no locale or Unicode normalization. Reordered or duplicate
merges at the same replica produce the same canonical snapshot. Replicas with
different IDs have the same converged causal contents but different local
`replicaId` fields.

Error tags are `invalid-input`, `invalid-state`, `invalid-json`,
`unsupported-version`, `kind-mismatch`, `conflicting-tag`, and
`counter-exhausted`. Callers may switch on tags; message text is diagnostic.

## Build and release

Use the versions in `mise.toml`: Gleam 1.18.1, Node 24.19.0, and pnpm 9.15.0.
The committed `manifest.toml` and `pnpm-lock.yaml` pin dependencies.

```sh
cd watershed_atlas
pnpm install --frozen-lockfile
pnpm test
pnpm test:package
```

`pnpm test` builds the ESM browser bundle and standalone TypeScript declarations,
then runs Gleam kernel-parity tests and the JavaScript contract tests.
The build checks the dependency graph and rejects non-kernel imports.

`pnpm test:package` builds and packs twice, with `gleam clean` between builds,
and requires identical tarball bytes. It installs the tarball offline into a
temporary consumer, checks its declarations, reruns the contract tests through
the package export, and bundles and executes a browser consumer without Node,
DOM, network, timers, clock, or randomness access. It also checks that private
module imports fail.

Release outputs are:

```text
dist/index.js
dist/index.d.ts
artifacts/tylerbutler-watershed-atlas-0.1.0.tgz
artifacts/tylerbutler-watershed-atlas-0.1.0.tgz.sha256
```

The tarball includes the README and license notices, but no build tree or
development dependencies. For a registry release, update both package versions,
run the checks, then publish the checked tarball:

```sh
npm publish artifacts/tylerbutler-watershed-atlas-0.1.0.tgz --access public
```

Trellis includes this package in JavaScript builds, Gleam tests, and bundles,
and excludes it from Erlang builds. Its lifecycle remains `git_only`; npm
publication uses the explicit command above rather than Hex.

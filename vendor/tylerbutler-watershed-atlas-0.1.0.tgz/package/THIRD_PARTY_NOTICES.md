# Bundled dependency notices

The bundle includes portions of Gleam's generated JavaScript prelude,
`gleam_stdlib`, and `gleam_json`, under Apache-2.0. The complete license is
in `dist/APACHE-2.0.txt`. Sources: <https://github.com/gleam-lang/gleam>,
<https://github.com/gleam-lang/stdlib>, and <https://github.com/gleam-lang/json>.

It also includes portions of `lattice_core`, `lattice_registers`, and
`lattice_sets` from <https://github.com/tylerbutler/lattice>, under this license:

```text
MIT License

Copyright (c) 2025 Tyler Butler

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

The Watershed kernels and this facade use the MIT license in `LICENSE`.
The Gleam and pnpm lockfiles in the source release pin the dependency versions.
